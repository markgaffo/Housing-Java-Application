/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public abstract class House implements Serializable{
    
    String type; // House types are Attached, Semi Detached, Detached
    int roomNum, floorNum;
    double price;
    
    public House()
    {
        type = "";
        roomNum = 0;
        floorNum = 0;
        price =0;
    }
    public House(String type, int roomNum,int floorNum, double price){
        this.type = type;
        this.roomNum = roomNum;
        this.floorNum = floorNum;
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String size) {
        this.type = size;
    }

    public int getRoomNum() {
        return roomNum;
    }

    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getFloorNum() {
        return floorNum;
    }

    public void setFloorNum(int floorNum) {
        this.floorNum = floorNum;
    }
    
    public String printDetails(){
        return "House type: "+type+ "\nNumber of Rooms: "+roomNum+"\nPrice is: "+price ;
    }
}

