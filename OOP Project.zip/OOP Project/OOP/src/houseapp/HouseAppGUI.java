/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author x17145953
 */
public class HouseAppGUI extends javax.swing.JFrame {
    //Container for the objects in arrayList
    House h;
    Person p;
    Area a;
    
    //Data members of House parent class and its subclasses BigHouse and MediumHouse
    String type, gardenSize, poolSize;
    int roomNum,floorNum, garageLimit;
    double price,total;
    
    
    //Data members of Person parent class and its subclasses Single and Married
    String name;
    int age, yearsMarried;
    double income;
    
    //Data members of Area parent class and its subclasses NorthDub and SouthDub
    String area;
    int timeToCity, northPostCode, southPostCode;
    double areaPricing;
    
    //Declaring an arrayList
    private ArrayList<Area> areaList;
    private ArrayList<House> house;
    private ArrayList<Person> person;
    
    
    

    /**
     * Creates new form TestGUI
     */
    public HouseAppGUI() {
        initComponents();
        total = 0;//This is the variable that saves the grant total from the Grant section
        
        //Instantiates the arrayList
        person = new ArrayList <>();
        house = new ArrayList <>();
        areaList = new ArrayList <>();
        
        
        //Hide displays/areas of the GUI
        disabledCBox.setVisible(false);
        calculateGBtn.setVisible(false);
        grantBtn.setVisible(false);
        houseAddBtn.setVisible(false);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(false);
        studentCBox.setVisible(false);
        unemployedCBox.setVisible(false);
        
        submitBtn.setVisible(false);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        chosenLbl.setVisible(false);
        chosenHousePriceTf.setVisible(false);
        totalPriceTf.setVisible(false);
        totalPriceLbl.setVisible(false);
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
        
        
        searchHouseBtn.setVisible(false);
        displayHouseBtn.setVisible(true);
        submitHouseBtn.setVisible(false);
        hTypeLbl.setVisible(false);
        hTypeTf.setVisible(false);
        roomNumLbl.setVisible(false);
        roomNumTf.setVisible(false);
        floorNumLbl.setVisible(false);
        floorNumTf.setVisible(false);
        priceLbl.setVisible(false);
        priceTf.setVisible(false);
        mediumBtn.setVisible(false);
        bigBtn.setVisible(false);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        addLbl.setVisible(false);
        chooseHouseBtn.setVisible(false);
        
        calculateGBtn.setVisible(false);
        displayInfobtn.setVisible(true);
        pNameTf.setVisible(false);
        pNameLbl.setVisible(false);
        pAgeTf.setVisible(false);
        pAgeLbl.setVisible(false);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        singleBtn.setVisible(false);
        marriedBtn.setVisible(false);
        searchPBtn.setVisible(false);
        deleteHouseBtn.setVisible(false);
        deletePersonBtn.setVisible(false);
        
        areaTf.setVisible(false);
        areaLbl.setVisible(false);
        areaPriceLbl.setVisible(false);
        areaPriceTf.setVisible(false);
        timeToCityTf.setVisible(false);
        timeToCityLbl.setVisible(false);
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        northBtn.setVisible(false);
        southBtn.setVisible(false);
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);
        
        displayHouseBtn.setVisible(false);
        displayAreaBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        chooseHouseBtn.setVisible(false);
        chooseAreaBtn.setVisible(false);
        priceAreaTf.setVisible(false);
        priceAreaLbl.setVisible(false);
        calcTotalBtn.setVisible(false);
        txtArea.setVisible(false);
        
        //Read from a file that has objects saved on
        readFromFileHouses();
        readFromFilePerson();
        readFromFileArea();
        
        
        
        
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        studentCBox = new javax.swing.JCheckBox();
        unemployedCBox = new javax.swing.JCheckBox();
        parentCBox = new javax.swing.JCheckBox();
        disabledCBox = new javax.swing.JCheckBox();
        calculateGBtn = new javax.swing.JButton();
        grantBtn = new javax.swing.JButton();
        houseAddBtn = new javax.swing.JButton();
        buyAHouseBtn = new javax.swing.JButton();
        submitBtn = new javax.swing.JButton();
        clearBtn = new javax.swing.JButton();
        exitBtn = new javax.swing.JButton();
        titleLbl = new javax.swing.JLabel();
        grantAmountLbl = new javax.swing.JLabel();
        grantAmountTf = new javax.swing.JTextField();
        hTypeLbl = new javax.swing.JLabel();
        roomNumLbl = new javax.swing.JLabel();
        floorNumLbl = new javax.swing.JLabel();
        priceLbl = new javax.swing.JLabel();
        gardenSizeLbl = new javax.swing.JLabel();
        garageLimitLbl = new javax.swing.JLabel();
        poolSizeLbl = new javax.swing.JLabel();
        submitHouseBtn = new javax.swing.JButton();
        displayHouseBtn = new javax.swing.JButton();
        searchHouseBtn = new javax.swing.JButton();
        bigBtn = new javax.swing.JButton();
        mediumBtn = new javax.swing.JButton();
        hTypeTf = new javax.swing.JTextField();
        roomNumTf = new javax.swing.JTextField();
        floorNumTf = new javax.swing.JTextField();
        priceTf = new javax.swing.JTextField();
        gardenSizeTf = new javax.swing.JTextField();
        garageLimitTf = new javax.swing.JTextField();
        poolSizeTf = new javax.swing.JTextField();
        totalPriceTf = new javax.swing.JTextField();
        chooseHouseBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        totalPriceLbl = new javax.swing.JLabel();
        chosenHousePriceTf = new javax.swing.JTextField();
        chosenLbl = new javax.swing.JLabel();
        pNameTf = new javax.swing.JTextField();
        pAgeTf = new javax.swing.JTextField();
        pNameLbl = new javax.swing.JLabel();
        pAgeLbl = new javax.swing.JLabel();
        mYearsTf = new javax.swing.JTextField();
        incomeTf = new javax.swing.JTextField();
        incomeLbl = new javax.swing.JLabel();
        mYearsLbl = new javax.swing.JLabel();
        displayInfobtn = new javax.swing.JButton();
        searchPBtn = new javax.swing.JButton();
        singleBtn = new javax.swing.JButton();
        marriedBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        addLbl = new javax.swing.JLabel();
        addPeopleBtn = new javax.swing.JButton();
        deletePersonBtn = new javax.swing.JButton();
        deleteHouseBtn = new javax.swing.JButton();
        areaMbtn = new javax.swing.JButton();
        areaTf = new javax.swing.JTextField();
        areaPriceTf = new javax.swing.JTextField();
        timeToCityTf = new javax.swing.JTextField();
        northCodeTf = new javax.swing.JTextField();
        southCodeTf = new javax.swing.JTextField();
        areaLbl = new javax.swing.JLabel();
        areaPriceLbl = new javax.swing.JLabel();
        timeToCityLbl = new javax.swing.JLabel();
        northCodeLbl = new javax.swing.JLabel();
        southCodeLbl = new javax.swing.JLabel();
        northBtn = new javax.swing.JButton();
        southBtn = new javax.swing.JButton();
        chooseAreaBtn = new javax.swing.JButton();
        areaAddBtn = new javax.swing.JButton();
        displayAreaBtn = new javax.swing.JButton();
        priceAreaLbl = new javax.swing.JLabel();
        priceAreaTf = new javax.swing.JTextField();
        searchAreaBtn = new javax.swing.JButton();
        calcTotalBtn = new javax.swing.JButton();
        payBtn = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        studentCBox.setText("Student");
        studentCBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentCBoxActionPerformed(evt);
            }
        });

        unemployedCBox.setText("Unemployed");
        unemployedCBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unemployedCBoxActionPerformed(evt);
            }
        });

        parentCBox.setText("Parent");
        parentCBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                parentCBoxActionPerformed(evt);
            }
        });

        disabledCBox.setText("Disabled");

        calculateGBtn.setText("Calculate grant");
        calculateGBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calculateGBtnActionPerformed(evt);
            }
        });

        grantBtn.setText("Apply for a grant");
        grantBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grantBtnActionPerformed(evt);
            }
        });

        houseAddBtn.setText("Add a House");
        houseAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                houseAddBtnActionPerformed(evt);
            }
        });

        buyAHouseBtn.setText("Buy A House");
        buyAHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyAHouseBtnActionPerformed(evt);
            }
        });

        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });

        clearBtn.setText("Clear All");
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        titleLbl.setText("Housing and Grant Application Forms");

        grantAmountLbl.setText("Grant amount:");

        grantAmountTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                grantAmountTfActionPerformed(evt);
            }
        });

        hTypeLbl.setText("Type");

        roomNumLbl.setText("No. of rooms");

        floorNumLbl.setText("No. of floors");

        priceLbl.setText("Price");

        gardenSizeLbl.setText("Garden size");

        garageLimitLbl.setText("Garage limit");

        poolSizeLbl.setText("Pool size");

        submitHouseBtn.setText("Submit");
        submitHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitHouseBtnActionPerformed(evt);
            }
        });

        displayHouseBtn.setText("Display Available Houses");
        displayHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayHouseBtnActionPerformed(evt);
            }
        });

        searchHouseBtn.setText("Search House by Type");
        searchHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchHouseBtnActionPerformed(evt);
            }
        });

        bigBtn.setText("Big House");
        bigBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bigBtnActionPerformed(evt);
            }
        });

        mediumBtn.setText("Medium House");
        mediumBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mediumBtnActionPerformed(evt);
            }
        });

        hTypeTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hTypeTfActionPerformed(evt);
            }
        });

        totalPriceTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalPriceTfActionPerformed(evt);
            }
        });

        chooseHouseBtn.setText("Choose a house");
        chooseHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseHouseBtnActionPerformed(evt);
            }
        });

        totalPriceLbl.setText("Total price:");

        chosenLbl.setText("Chosen house price:");

        pNameTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pNameTfActionPerformed(evt);
            }
        });

        pNameLbl.setText("Name");

        pAgeLbl.setText("Age");

        incomeLbl.setText("Income");

        mYearsLbl.setText("Years married");

        displayInfobtn.setText("Display people who applied for grant");
        displayInfobtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayInfobtnActionPerformed(evt);
            }
        });

        searchPBtn.setText("Search Person");
        searchPBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchPBtnActionPerformed(evt);
            }
        });

        singleBtn.setText("Single");
        singleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                singleBtnActionPerformed(evt);
            }
        });

        marriedBtn.setText("Married");
        marriedBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                marriedBtnActionPerformed(evt);
            }
        });

        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        addLbl.setText("Add a House interface");

        addPeopleBtn.setText("Add people ");
        addPeopleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPeopleBtnActionPerformed(evt);
            }
        });

        deletePersonBtn.setText("Delete Person");
        deletePersonBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePersonBtnActionPerformed(evt);
            }
        });

        deleteHouseBtn.setText("Delete House");
        deleteHouseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteHouseBtnActionPerformed(evt);
            }
        });

        areaMbtn.setText("Add Area");
        areaMbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                areaMbtnActionPerformed(evt);
            }
        });

        areaLbl.setText("Area");

        areaPriceLbl.setText("Price of area");

        timeToCityLbl.setText("Time to city in minutes");

        northCodeLbl.setText("North Post Code");

        southCodeLbl.setText("South PostCode");

        northBtn.setText("North");
        northBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                northBtnActionPerformed(evt);
            }
        });

        southBtn.setText("South");
        southBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                southBtnActionPerformed(evt);
            }
        });

        chooseAreaBtn.setText("Choose Area");
        chooseAreaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chooseAreaBtnActionPerformed(evt);
            }
        });

        areaAddBtn.setText("Submit");
        areaAddBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                areaAddBtnActionPerformed(evt);
            }
        });

        displayAreaBtn.setText("Display Available Area");
        displayAreaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayAreaBtnActionPerformed(evt);
            }
        });

        priceAreaLbl.setText("Area price");

        searchAreaBtn.setText("Search Area");
        searchAreaBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchAreaBtnActionPerformed(evt);
            }
        });

        calcTotalBtn.setText("Calculate Total Price");
        calcTotalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calcTotalBtnActionPerformed(evt);
            }
        });

        payBtn.setText("Pay");
        payBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(deleteHouseBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchHouseBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(gardenSizeLbl)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(120, 120, 120)
                                                .addComponent(titleLbl)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(roomNumLbl)
                                            .addComponent(floorNumLbl)
                                            .addComponent(priceLbl)
                                            .addComponent(hTypeLbl)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(17, 17, 17)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                        .addGroup(layout.createSequentialGroup()
                                                            .addComponent(pAgeLbl)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                            .addComponent(pAgeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                            .addComponent(pNameLbl)
                                                            .addGap(9, 9, 9)
                                                            .addComponent(pNameTf, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(grantBtn)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(buyAHouseBtn)))))
                                        .addGap(2, 2, 2)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(33, 33, 33)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(mYearsLbl)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(mYearsTf, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(incomeLbl)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(incomeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(4, 4, 4)
                                                .addComponent(addPeopleBtn)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(areaMbtn)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(houseAddBtn)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(areaLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(areaPriceLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(timeToCityLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(northCodeLbl, javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                            .addComponent(northBtn)
                                                            .addComponent(areaAddBtn))
                                                        .addGap(21, 21, 21))
                                                    .addComponent(southCodeLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                                                .addGap(29, 29, 29)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(northCodeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(timeToCityTf, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(areaPriceTf, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(areaTf, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(southBtn)
                                                    .addComponent(searchAreaBtn)
                                                    .addComponent(southCodeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(14, 14, 14))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 115, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(unemployedCBox)
                                                .addGap(37, 37, 37)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(studentCBox)
                                                    .addComponent(parentCBox))
                                                .addGap(68, 68, 68)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(singleBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(marriedBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(disabledCBox)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(calculateGBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(deletePersonBtn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(roomNumTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(hTypeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(floorNumTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(priceTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(gardenSizeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(garageLimitTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(poolSizeTf, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(submitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(searchPBtn)
                                                    .addComponent(mediumBtn)
                                                    .addComponent(bigBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(192, 192, 192)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(displayHouseBtn)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(displayAreaBtn))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(chooseHouseBtn)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(chooseAreaBtn))
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(calcTotalBtn)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(chosenLbl)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(totalPriceLbl)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jLabel2))
                                                    .addComponent(priceAreaLbl)
                                                    .addComponent(grantAmountLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(38, 38, 38)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(chosenHousePriceTf, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                                                        .addComponent(priceAreaTf)
                                                        .addComponent(totalPriceTf))
                                                    .addComponent(grantAmountTf, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addComponent(payBtn)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(displayInfobtn)
                                .addGap(102, 102, 102)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(garageLimitLbl)
                            .addComponent(submitHouseBtn)
                            .addComponent(addLbl)
                            .addComponent(poolSizeLbl))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(displayHouseBtn)
                            .addComponent(displayAreaBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(displayInfobtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chooseHouseBtn)
                            .addComponent(chooseAreaBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chosenHousePriceTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chosenLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(areaTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(areaLbl)
                            .addComponent(priceAreaLbl)
                            .addComponent(priceAreaTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(areaPriceTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(areaPriceLbl)
                            .addComponent(grantAmountLbl)
                            .addComponent(grantAmountTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(totalPriceLbl)
                                .addComponent(totalPriceTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(timeToCityTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(timeToCityLbl)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(northCodeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(northCodeLbl)
                            .addComponent(calcTotalBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(southCodeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(southCodeLbl)
                            .addComponent(payBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(northBtn)
                            .addComponent(southBtn))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(exitBtn)
                            .addComponent(clearBtn)
                            .addComponent(deleteHouseBtn)
                            .addComponent(searchHouseBtn)
                            .addComponent(areaAddBtn)
                            .addComponent(searchAreaBtn))
                        .addGap(11, 11, 11))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(titleLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(grantBtn)
                            .addComponent(addPeopleBtn)
                            .addComponent(areaMbtn)
                            .addComponent(buyAHouseBtn)
                            .addComponent(houseAddBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pNameTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pNameLbl)
                            .addComponent(incomeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(incomeLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(pAgeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pAgeLbl)
                            .addComponent(mYearsTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mYearsLbl))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(unemployedCBox)
                            .addComponent(parentCBox)
                            .addComponent(singleBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(disabledCBox)
                            .addComponent(studentCBox)
                            .addComponent(marriedBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(submitBtn)
                            .addComponent(calculateGBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchPBtn)
                            .addComponent(deletePersonBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(addLbl)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(hTypeLbl)
                            .addComponent(hTypeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mediumBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(roomNumLbl)
                            .addComponent(roomNumTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bigBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(floorNumTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(floorNumLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(priceTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(priceLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(gardenSizeLbl)
                            .addComponent(gardenSizeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(garageLimitLbl)
                            .addComponent(garageLimitTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(poolSizeTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(poolSizeLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(submitHouseBtn)
                        .addGap(68, 68, 68))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void studentCBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentCBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentCBoxActionPerformed

    private void parentCBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_parentCBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_parentCBoxActionPerformed

    private void calculateGBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calculateGBtnActionPerformed
        // TODO add your handling code here:
        
        //Grant calculation
        //radio boxes
        if(p instanceof Married){
            total = total + 0.0;          
        }
        else if (p instanceof Single) {
            total = total + 400;
        }
        //check boxes
        if(disabledCBox.isSelected()){
            total = total + 300;
        }
        if(parentCBox.isSelected()){
            total = total + 450;
        }
        if(studentCBox.isSelected()){
            total = total + 250;
        }
        if(unemployedCBox.isSelected()){
            total = total + 400;
        }
        //grant amount
        grantAmountTf.setText(Double.toString(total));
        
        total = Double.parseDouble(grantAmountTf.getText());
        
        
    }//GEN-LAST:event_calculateGBtnActionPerformed

    private void grantBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grantBtnActionPerformed
        // TODO add your handling code here:
        
        //Hides areas irrelevant with the grant section and displays relevant ones
        disabledCBox.setVisible(true);
        calculateGBtn.setVisible(true);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(true);
        studentCBox.setVisible(true);
        unemployedCBox.setVisible(true);
        
        submitBtn.setVisible(false);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        grantAmountTf.setVisible(true);
        grantAmountLbl.setVisible(true);
        
        
        searchHouseBtn.setVisible(false);
        displayHouseBtn.setVisible(false);
        submitHouseBtn.setVisible(false);
        hTypeLbl.setVisible(false);
        hTypeTf.setVisible(false);
        roomNumLbl.setVisible(false);
        roomNumTf.setVisible(false);
        floorNumLbl.setVisible(false);
        floorNumTf.setVisible(false);
        priceLbl.setVisible(false);
        priceTf.setVisible(false);
        mediumBtn.setVisible(false);
        bigBtn.setVisible(false);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        addLbl.setVisible(false);
        chooseHouseBtn.setVisible(false);
        
        calculateGBtn.setVisible(true);
        displayInfobtn.setVisible(true);
        pNameTf.setVisible(true);
        pNameLbl.setVisible(true);
        pAgeTf.setVisible(true);
        pAgeLbl.setVisible(true);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        singleBtn.setVisible(true);
        marriedBtn.setVisible(true);
        searchPBtn.setVisible(true);
        
        chosenLbl.setVisible(false);
        chosenHousePriceTf.setVisible(false);
        totalPriceTf.setVisible(false);
        totalPriceLbl.setVisible(false);
        deleteHouseBtn.setVisible(false);
        deletePersonBtn.setVisible(false);
        
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);
        
        displayHouseBtn.setVisible(false);
        displayAreaBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        chooseHouseBtn.setVisible(false);
        chooseAreaBtn.setVisible(false);
        priceAreaTf.setVisible(false);
        priceAreaLbl.setVisible(false);
        calcTotalBtn.setVisible(false);
        
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
        payBtn.setVisible(false);
        txtArea.setVisible(true);
   
        
        
        
    }//GEN-LAST:event_grantBtnActionPerformed

    private void buyAHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyAHouseBtnActionPerformed
            // TODO add your handling code here:
        //House section hides all irrelevant data and shows all of its areas    
        JOptionPane.showMessageDialog(null, "Choose the house you want to buy by clicking 'Choose House' underneath the text area.\nThen choose an area by clicking 'Choose Area',\nClicking the Calculate Total Price button will show the house price + the area price minus the grant amount(if applicable)");
        northBtn.setVisible(false);
        southBtn.setVisible(false);
        
        disabledCBox.setVisible(false);
        calculateGBtn.setVisible(false);
        grantBtn.setVisible(false);
        houseAddBtn.setVisible(false);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(false);
        studentCBox.setVisible(false);
        unemployedCBox.setVisible(false);
        
        submitBtn.setVisible(false);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        grantAmountTf.setVisible(true);
        grantAmountLbl.setVisible(true);
        chosenLbl.setVisible(true);
        chosenHousePriceTf.setVisible(true);
        totalPriceTf.setVisible(true);
        totalPriceLbl.setVisible(true);
        grantAmountTf.setVisible(true);
        grantAmountLbl.setVisible(true);
        
        
        searchHouseBtn.setVisible(false);
        displayHouseBtn.setVisible(true);
        submitHouseBtn.setVisible(false);
        hTypeLbl.setVisible(false);
        hTypeTf.setVisible(false);
        roomNumLbl.setVisible(false);
        roomNumTf.setVisible(false);
        floorNumLbl.setVisible(false);
        floorNumTf.setVisible(false);
        priceLbl.setVisible(false);
        priceTf.setVisible(false);
        mediumBtn.setVisible(false);
        bigBtn.setVisible(false);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        addLbl.setVisible(false);
        
        calculateGBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        pNameTf.setVisible(false);
        pNameLbl.setVisible(false);
        pAgeTf.setVisible(false);
        pAgeLbl.setVisible(false);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        singleBtn.setVisible(false);
        marriedBtn.setVisible(false);
        searchPBtn.setVisible(false);
        
        chooseHouseBtn.setVisible(true);
        deleteHouseBtn.setVisible(false);
        deletePersonBtn.setVisible(false);
        
        areaTf.setVisible(false);
        areaLbl.setVisible(false);
        areaPriceLbl.setVisible(false);
        areaPriceTf.setVisible(false);
        timeToCityTf.setVisible(false);
        timeToCityLbl.setVisible(false);
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        northBtn.setVisible(false);
        southBtn.setVisible(false);
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);
        
        displayHouseBtn.setVisible(true);
        displayAreaBtn.setVisible(true);
        displayInfobtn.setVisible(true);
        chooseHouseBtn.setVisible(true);
        chooseAreaBtn.setVisible(true);
        priceAreaTf.setVisible(true);
        priceAreaLbl.setVisible(true);
        calcTotalBtn.setVisible(true);
        txtArea.setVisible(true);
        payBtn.setVisible(true);
    }//GEN-LAST:event_buyAHouseBtnActionPerformed

    private void unemployedCBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unemployedCBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_unemployedCBoxActionPerformed

    private void houseAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_houseAddBtnActionPerformed
        // TODO add your handling code here:
        
        //House section that adds a "house" that user inputs
        searchHouseBtn.setVisible(true);
        displayHouseBtn.setVisible(true);
        submitHouseBtn.setVisible(true);
        hTypeLbl.setVisible(true);
        hTypeTf.setVisible(true);
        roomNumLbl.setVisible(true);
        roomNumTf.setVisible(true);
        floorNumLbl.setVisible(true);
        floorNumTf.setVisible(true);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        disabledCBox.setVisible(false);
        calculateGBtn.setVisible(false);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(false);
        studentCBox.setVisible(false);
        unemployedCBox.setVisible(false);
        
        submitBtn.setVisible(false);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        grantAmountTf.setVisible(true);
        grantAmountLbl.setVisible(true);
        mediumBtn.setVisible(true);
        bigBtn.setVisible(true);
        priceLbl.setVisible(true);
        priceTf.setVisible(true);
        addLbl.setVisible(true);
        chosenLbl.setVisible(false);
        chosenHousePriceTf.setVisible(false);
        totalPriceTf.setVisible(false);
        totalPriceLbl.setVisible(false);
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
        
        
        calculateGBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        pNameTf.setVisible(false);
        pNameLbl.setVisible(false);
        pAgeTf.setVisible(false);
        pAgeLbl.setVisible(false);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);        
        singleBtn.setVisible(false);
        marriedBtn.setVisible(false);
        searchPBtn.setVisible(false);
        
        chooseHouseBtn.setVisible(false);
        deleteHouseBtn.setVisible(true);
        deletePersonBtn.setVisible(false);
        
        areaTf.setVisible(false);
        areaLbl.setVisible(false);
        areaPriceLbl.setVisible(false);
        areaPriceTf.setVisible(false);
        timeToCityTf.setVisible(false);
        timeToCityLbl.setVisible(false);
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        
        northBtn.setVisible(false);
        southBtn.setVisible(false);
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);
        
        displayHouseBtn.setVisible(false);
        displayAreaBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        chooseHouseBtn.setVisible(false);
        chooseAreaBtn.setVisible(false);
        priceAreaTf.setVisible(false);
        priceAreaLbl.setVisible(false);
        calcTotalBtn.setVisible(false);
        txtArea.setVisible(true);
        payBtn.setVisible(false);
    }//GEN-LAST:event_houseAddBtnActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // TODO add your handling code here:
        //Adds an object into the person arrayList
        //This one is for the Married subclass
         if(p instanceof Married){

            p = new Married();
            name = pNameTf.getText();
            age = Integer.parseInt(pAgeTf.getText());
            yearsMarried = Integer.parseInt(mYearsTf.getText());
            
            

            p.setName(name);
            p.setAge(age);
            
            
            ((Married)p).setYearsMarried(yearsMarried);

            person.add(p);
            //Adds it into the arrayList

        }
       //This one is for the Single subclass
       if(p instanceof Single){

            p = new Single();
            name = pNameTf.getText();
            age = Integer.parseInt(pAgeTf.getText());
            income = Double.parseDouble(incomeTf.getText());
            
            

            p.setName(name);
            p.setAge(age);
           
            
            ((Single)p).setIncome(income);

            person.add(p);
            //Adds it into the arrayList
        }
       //Writes the input onto a file and saves it
       writeToFilePerson();
    }//GEN-LAST:event_submitBtnActionPerformed

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        // TODO add your handling code here:
        //Exits the system
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        // TODO add your handling code here:
        
        //Clears all text fields
        
        disabledCBox.setSelected(false);
        parentCBox.setSelected(false);
        unemployedCBox.setSelected(false);
        studentCBox.setSelected(false);
        grantAmountTf.setText(" ");
        txtArea.setText(" ");
        pNameTf.setText(" ");
        pAgeTf.setText(" ");
        incomeTf.setText(" ");
        mYearsTf.setText(" ");
      
        
        hTypeTf.setText(" ");        
        roomNumTf.setText(" ");       
        floorNumTf.setText(" ");
        priceTf.setText(" ");
        gardenSizeTf.setText(" ");
        garageLimitTf.setText(" ");
        poolSizeTf.setText(" ");
        chosenHousePriceTf.setText(" ");
        priceAreaTf.setText(" ");
        totalPriceTf.setText(" ");
        
        areaTf.setText(" ");
     
        
        areaPriceTf.setText(" ");
        timeToCityTf.setText(" ");
        
        northCodeTf.setText(" ");
        
        southCodeTf.setText(" ");
       
   
        
    }//GEN-LAST:event_clearBtnActionPerformed

    private void grantAmountTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_grantAmountTfActionPerformed
        // TODO add your handling code here:
        
        
    }//GEN-LAST:event_grantAmountTfActionPerformed

    private void submitHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitHouseBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds an object into the house arrayList
        //This one is for the MediumHouse subclass
        if(h instanceof MediumHouse){

            h = new MediumHouse();
            type = hTypeTf.getText();
            roomNum = Integer.parseInt(roomNumTf.getText());
            floorNum = Integer.parseInt(floorNumTf.getText());
            price = Double.parseDouble(priceTf.getText());
            gardenSize = gardenSizeTf.getText();
            garageLimit = Integer.parseInt(garageLimitTf.getText());

            h.setType(type);
            h.setRoomNum(roomNum);
            h.setFloorNum(floorNum);
            h.setPrice(price);

            ((MediumHouse)h).setGardenSize(gardenSize);
            ((MediumHouse)h).setGarageLimit(garageLimit);

            house.add(h);
        //Adds into the house arrayList
        }
        //This one is for the BigHouse subclass
        if(h instanceof BigHouse){

            h = new BigHouse();
            type = hTypeTf.getText();
            roomNum = Integer.parseInt(roomNumTf.getText());
            floorNum = Integer.parseInt(floorNumTf.getText());
            price = Double.parseDouble(priceTf.getText());
            gardenSize = gardenSizeTf.getText();
            garageLimit = Integer.parseInt(garageLimitTf.getText());
            poolSize = poolSizeTf.getText();

            h.setType(type);
            h.setRoomNum(roomNum);
            h.setFloorNum(floorNum);
            h.setPrice(price);

            ((BigHouse)h).setGardenSize(gardenSize);
            ((BigHouse)h).setGarageLimit(garageLimit);
            ((BigHouse)h).setPoolSize(poolSize);

            house.add(h);
         //Adds into the house arrayList
        }
        //Saves input onto a file
        writeToFileHouses();
        
    }//GEN-LAST:event_submitHouseBtnActionPerformed

    private void displayHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayHouseBtnActionPerformed
        // TODO add your handling code here:
        
        //Displays all objects in the house arrayList
        for(House h:house){
            txtArea.append(h.printDetails()+ "\n\n");
        }
    }//GEN-LAST:event_displayHouseBtnActionPerformed

    private void searchHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchHouseBtnActionPerformed
        // TODO add your handling code here:
        
        //Allows users to search a house(s) by their type 
        String searchType = JOptionPane.showInputDialog(null, "Enter house type to search");
        for(House x:house){
            if(searchType.equalsIgnoreCase(x.getType())){
                JOptionPane.showMessageDialog(null, "Type: "+x.printDetails());
            }
            else if(searchType.equals(" ")){
                JOptionPane.showMessageDialog(null, "Please enter appropriate values");
            }
        }
    }//GEN-LAST:event_searchHouseBtnActionPerformed

    private void bigBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bigBtnActionPerformed
        // TODO add your handling code here:
        
        //Button that creates an object under the BigHouse subclass
        roomNumTf.setVisible(true);
        roomNumLbl.setVisible(true);
        floorNumTf.setVisible(true);
        floorNumLbl.setVisible(true);
        priceTf.setVisible(true);
        priceLbl.setVisible(true);
        gardenSizeLbl.setVisible(true);
        gardenSizeTf.setVisible(true);
        garageLimitTf.setVisible(true);
        garageLimitLbl.setVisible(true);
        poolSizeLbl.setVisible(true);
        poolSizeTf.setVisible(true);

        h = new BigHouse();
    }//GEN-LAST:event_bigBtnActionPerformed

    private void mediumBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mediumBtnActionPerformed
        // TODO add your handling code here:

        //Button that creates an object under the MediumHouse subclass
        roomNumTf.setVisible(true);
        roomNumLbl.setVisible(true);
        floorNumTf.setVisible(true);
        floorNumLbl.setVisible(true);
        priceTf.setVisible(true);
        priceLbl.setVisible(true);
        gardenSizeLbl.setVisible(true);
        gardenSizeTf.setVisible(true);
        garageLimitTf.setVisible(true);
        garageLimitLbl.setVisible(true);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);

        h = new MediumHouse();
    }//GEN-LAST:event_mediumBtnActionPerformed

    private void hTypeTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hTypeTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hTypeTfActionPerformed

    private void totalPriceTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalPriceTfActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_totalPriceTfActionPerformed

    private void chooseHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseHouseBtnActionPerformed
        // TODO add your handling code here:
         
        //Button that lets users enter the house type and price of the house they wish to buy
        String searchHouse = JOptionPane.showInputDialog(null, "Enter house type you want to buy");
        double searchHousePrice =Double.parseDouble(JOptionPane.showInputDialog(null, "Enter house price you want to buy"));
        
        //Looping through an arrayList
        for(House x: house){
            
            if(searchHouse.equals(x.getType())&& searchHousePrice==x.getPrice()){
                
              chosenHousePriceTf.setText(Double.toString(x.getPrice()));
             
              JOptionPane.showMessageDialog(null, "Chosen house type is: "+x.getType());
            } 
            else if(searchHouse.equals(" ")&& searchHousePrice==(0)){
                JOptionPane.showMessageDialog(null, "Please enter valid values.");
            }
       }
    }//GEN-LAST:event_chooseHouseBtnActionPerformed

    private void displayInfobtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayInfobtnActionPerformed
        // TODO add your handling code here:
         
        //Displays all objects the person arrayList contains on the text area
         for(Person p:person){
             txtArea.append(p.printPerDetails()+ "\n\n");
        }
        
    }//GEN-LAST:event_displayInfobtnActionPerformed

    private void searchPBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchPBtnActionPerformed
        // TODO add your handling code here:
        //Allows users to search for a person by getting their name
        String searchType = JOptionPane.showInputDialog(null, "Enter person name to search");
        for(int i = 0; i < person.size(); i++){
            if(searchType.equalsIgnoreCase(person.get(i).getName())){
                JOptionPane.showMessageDialog(null, "Name: "+person.get(i).getName()+"\n Age: "+person.get(i).getAge());
            }
        }
    }//GEN-LAST:event_searchPBtnActionPerformed

    private void singleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_singleBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds into the Single subclass
        pNameTf.setVisible(true);
        pNameLbl.setVisible(true);
        pAgeTf.setVisible(true);
        pAgeLbl.setVisible(true);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        incomeLbl.setVisible(true);
        incomeTf.setVisible(true);
        
        p = new Single();
    }//GEN-LAST:event_singleBtnActionPerformed

    private void marriedBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_marriedBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds into the Married subclass
        pNameTf.setVisible(true);
        pNameLbl.setVisible(true);
        pAgeTf.setVisible(true);
        pAgeLbl.setVisible(true);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(true);
        mYearsTf.setVisible(true);
        
        p = new Married();
    }//GEN-LAST:event_marriedBtnActionPerformed

    private void pNameTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pNameTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pNameTfActionPerformed

    private void addPeopleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPeopleBtnActionPerformed
         // TODO add your handling code here:
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);        
        southBtn.setVisible(false);       
        northBtn.setVisible(false);
        
        disabledCBox.setVisible(true);
        calculateGBtn.setVisible(false);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(true);
        studentCBox.setVisible(true);
        unemployedCBox.setVisible(true);
        
        submitBtn.setVisible(true);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
       
        
        searchHouseBtn.setVisible(false);
        displayHouseBtn.setVisible(false);
        submitHouseBtn.setVisible(false);
        hTypeLbl.setVisible(false);
        hTypeTf.setVisible(false);
        roomNumLbl.setVisible(false);
        roomNumTf.setVisible(false);
        floorNumLbl.setVisible(false);
        floorNumTf.setVisible(false);
        priceLbl.setVisible(false);
        priceTf.setVisible(false);
        mediumBtn.setVisible(false);
        bigBtn.setVisible(false);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        addLbl.setVisible(false);
        chooseHouseBtn.setVisible(false);
        
        
        displayInfobtn.setVisible(true);
        pNameTf.setVisible(true);
        pNameLbl.setVisible(true);
        pAgeTf.setVisible(true);
        pAgeLbl.setVisible(true);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        singleBtn.setVisible(true);
        marriedBtn.setVisible(true);
        searchPBtn.setVisible(true);
        deleteHouseBtn.setVisible(false);
        deletePersonBtn.setVisible(true);
       
        areaTf.setVisible(false);
        areaLbl.setVisible(false);
        areaPriceLbl.setVisible(false);
        areaPriceTf.setVisible(false);
        timeToCityTf.setVisible(false);
        timeToCityLbl.setVisible(false);
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        northBtn.setVisible(false);
        southBtn.setVisible(false);
        areaAddBtn.setVisible(false);
        searchAreaBtn.setVisible(false);
        
        displayHouseBtn.setVisible(false);
        displayAreaBtn.setVisible(false);
        displayInfobtn.setVisible(true);
        chooseHouseBtn.setVisible(false);
        chooseAreaBtn.setVisible(false);
        priceAreaTf.setVisible(false);
        priceAreaLbl.setVisible(false);
        calcTotalBtn.setVisible(false);
        
        txtArea.setVisible(true);
        payBtn.setVisible(false);
    }//GEN-LAST:event_addPeopleBtnActionPerformed

    private void deletePersonBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePersonBtnActionPerformed
        // TODO add your handling code here:
        
        //Lets users delete a Person object by asking them the name and then looping through the arrayList and comparing the user name input and object name
        
        String searchType = JOptionPane.showInputDialog(null, "Enter person name to delete");
        for(int i = 0; i < person.size(); i++){
            if(searchType.equalsIgnoreCase(person.get(i).getName())){
                person.remove(i);
                JOptionPane.showMessageDialog(null, "Person is deleted");
            }
        }
    }//GEN-LAST:event_deletePersonBtnActionPerformed

    private void deleteHouseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteHouseBtnActionPerformed
        // TODO add your handling code here:
        
        //Lets users delete a House object by asking them the type and then looping through the arrayList and comparing the user type input and object type
        String searchType = JOptionPane.showInputDialog(null, "Enter house type to delete");
        for(int i = 0; i < house.size(); i++){
            if(searchType.equalsIgnoreCase(house.get(i).getType())){
                house.remove(i);
                JOptionPane.showMessageDialog(null, "House is deleted");
            }
        }
    }//GEN-LAST:event_deleteHouseBtnActionPerformed

    private void areaMbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_areaMbtnActionPerformed
        // TODO add your handling code here:
        
        disabledCBox.setVisible(false);
        calculateGBtn.setVisible(false);
        grantBtn.setVisible(false);
        grantBtn.setVisible(true);
        houseAddBtn.setVisible(true);
        
        buyAHouseBtn.setVisible(true);
        parentCBox.setVisible(false);
        studentCBox.setVisible(false);
        unemployedCBox.setVisible(false);
        
        submitBtn.setVisible(false);
        clearBtn.setVisible(true);
        exitBtn.setVisible(true);
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
        chosenLbl.setVisible(false);
        chosenHousePriceTf.setVisible(false);
        totalPriceTf.setVisible(false);
        totalPriceLbl.setVisible(false);
        grantAmountTf.setVisible(false);
        grantAmountLbl.setVisible(false);
        
        
        searchHouseBtn.setVisible(false);
        displayHouseBtn.setVisible(false);
        submitHouseBtn.setVisible(false);
        hTypeLbl.setVisible(false);
        hTypeTf.setVisible(false);
        roomNumLbl.setVisible(false);
        roomNumTf.setVisible(false);
        floorNumLbl.setVisible(false);
        floorNumTf.setVisible(false);
        priceLbl.setVisible(false);
        priceTf.setVisible(false);
        mediumBtn.setVisible(false);
        bigBtn.setVisible(false);
        gardenSizeLbl.setVisible(false);
        gardenSizeTf.setVisible(false);
        garageLimitTf.setVisible(false);
        garageLimitLbl.setVisible(false);
        poolSizeLbl.setVisible(false);
        poolSizeTf.setVisible(false);
        addLbl.setVisible(false);
        
        calculateGBtn.setVisible(false);
        displayInfobtn.setVisible(false);
        pNameTf.setVisible(false);
        pNameLbl.setVisible(false);
        pAgeTf.setVisible(false);
        pAgeLbl.setVisible(false);
        incomeLbl.setVisible(false);
        incomeTf.setVisible(false);
        mYearsLbl.setVisible(false);
        mYearsTf.setVisible(false);
        singleBtn.setVisible(false);
        marriedBtn.setVisible(false);
        searchPBtn.setVisible(false);
        
        chooseHouseBtn.setVisible(true);
        deleteHouseBtn.setVisible(false);
        deletePersonBtn.setVisible(false);
        
        areaTf.setVisible(true);
        areaLbl.setVisible(true);
        areaPriceLbl.setVisible(true);
        areaPriceTf.setVisible(true);
        timeToCityTf.setVisible(true);
        timeToCityLbl.setVisible(true);
        northCodeTf.setVisible(true);
        northCodeLbl.setVisible(true);
        southCodeTf.setVisible(true);
        southCodeLbl.setVisible(true);
        northBtn.setVisible(true);
        southBtn.setVisible(true);
        areaAddBtn.setVisible(true);
        searchAreaBtn.setVisible(true);
        
        displayHouseBtn.setVisible(false);
        displayAreaBtn.setVisible(true);
        displayInfobtn.setVisible(false);
        chooseHouseBtn.setVisible(false);
        chooseAreaBtn.setVisible(false);
        priceAreaTf.setVisible(false);
        priceAreaLbl.setVisible(false);
        calcTotalBtn.setVisible(false);
        txtArea.setVisible(true);
        payBtn.setVisible(false);
        
    }//GEN-LAST:event_areaMbtnActionPerformed

    private void northBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_northBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds object under the NorthDub subclass
        northCodeTf.setVisible(true);
        northCodeLbl.setVisible(true);
        southCodeTf.setVisible(false);
        southCodeLbl.setVisible(false);
        
        a = new NorthDub();
    }//GEN-LAST:event_northBtnActionPerformed

    private void southBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_southBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds object under the SouthDub subclass
        northCodeTf.setVisible(false);
        northCodeLbl.setVisible(false);
        southCodeTf.setVisible(true);
        southCodeLbl.setVisible(true);
        
        a = new SouthDub();  
    }//GEN-LAST:event_southBtnActionPerformed

    private void areaAddBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_areaAddBtnActionPerformed
        // TODO add your handling code here:
        
        //Adds what the user put to SouthDub subclass
         if(a instanceof SouthDub){

            a = new SouthDub();
            area = areaTf.getText();
            areaPricing = Double.parseDouble(areaPriceTf.getText());
            timeToCity = Integer.parseInt(timeToCityTf.getText());
            southPostCode = Integer.parseInt(southCodeTf.getText());
            

            a.setArea(area);
            a.setAreaPricing(areaPricing);
            a.setTimeToCity(timeToCity);
            

            ((SouthDub)a).setSouthPostCode(southPostCode);
            

            areaList.add(a);

        }
         //Adds what the user put to SouthDub subclass
        if(a instanceof NorthDub){

            a = new NorthDub();
            area = areaTf.getText();
            areaPricing = Double.parseDouble(areaPriceTf.getText());
            timeToCity = Integer.parseInt(timeToCityTf.getText());
            northPostCode = Integer.parseInt(northCodeTf.getText());
            

            a.setArea(area);
            a.setAreaPricing(areaPricing);
            a.setTimeToCity(timeToCity);
            

            ((NorthDub)a).setNorthPostCode(northPostCode);
            
            

            areaList.add(a);

        }
        //Saves the object values into a file
        writeToFileArea();
    }//GEN-LAST:event_areaAddBtnActionPerformed

    private void displayAreaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayAreaBtnActionPerformed
        // TODO add your handling code here:
        
        //Displays all object that is in the arealist arrayList
         for(Area a:areaList){
            txtArea.append(a.printAreaDetails()+ "\n\n");
        }
    }//GEN-LAST:event_displayAreaBtnActionPerformed

    private void searchAreaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchAreaBtnActionPerformed
        // TODO add your handling code here:
        
        //Allows users to search for an area using a for loop on the arrayList
        String searchArea = JOptionPane.showInputDialog(null, "Enter area to search");
        for(Area x:areaList){
            if(searchArea.equalsIgnoreCase(x.getArea())){
                
                priceAreaTf.setText(Double.toString(x.getAreaPricing()));
                JOptionPane.showMessageDialog(null, "Type: "+x.printAreaDetails());
                
                
            }
            
             
        }
    }//GEN-LAST:event_searchAreaBtnActionPerformed

    private void chooseAreaBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chooseAreaBtnActionPerformed
        // TODO add your handling code here:
        
        //Lets users choose an area when buying a house. Wil ask area and the code. Uses a for loop
        String searchArea = JOptionPane.showInputDialog(null, "Enter area you want to choose");
        String searchCode = JOptionPane.showInputDialog(null, "Enter area code you want to buy");
        
        for(Area x: areaList){
            // && searchHousePrice.equals(house.get(i).getPrice())
            if(searchArea.equals(x.getArea())){
                
              priceAreaTf.setText(Double.toString(x.getAreaPricing()));
              
              JOptionPane.showMessageDialog(null, "Chosen area is: "+x.getArea());
            }
            else if(searchArea.equals(" ")&& searchCode.equals(" ")){
                JOptionPane.showMessageDialog(null, "Please enter valid values.");
            }
       }
       
        
        
        
    }//GEN-LAST:event_chooseAreaBtnActionPerformed

    private void calcTotalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calcTotalBtnActionPerformed
        // TODO add your handling code here:
        //Calculates the total amount = Adds the Price of the area and Price of the house chosen
        double housePrice=Double.parseDouble(chosenHousePriceTf.getText());
        double areaPrice=Double.parseDouble(priceAreaTf.getText());
        
         totalPriceTf.setText(Double.toString((housePrice+areaPrice)-total));
    }//GEN-LAST:event_calcTotalBtnActionPerformed

    private void payBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payBtnActionPerformed
        // TODO add your handling code here:
        
        //Lets users pay for the house they bought
        
             double totalPrice=Double.parseDouble(totalPriceTf.getText());
             double payAmount =Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter your pay"));
        if(payAmount>totalPrice){
           double change = payAmount-totalPrice;
            JOptionPane.showMessageDialog(null, "Your change is: "+change);
        }
        else if(payAmount<totalPrice){
            JOptionPane.showMessageDialog(null, "Insufficient funds");
        }
        else{
            JOptionPane.showMessageDialog(null, "Thank you");
        }
    }//GEN-LAST:event_payBtnActionPerformed
    
    //The following codes are the File I/O methods for each of the parent class and their subclasses' methods
    public void writeToFileHouses(){
        try{
            File f = new File("house.dat");//declare and create File object
            FileOutputStream fStream = new FileOutputStream(f);
            ObjectOutputStream oStream = new ObjectOutputStream(fStream);
            //write the object
            oStream.writeObject(house);
            //close the output stream
            oStream.close();
            
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    public void readFromFileHouses(){
        try{
            //delcare and create objects for input
            File f = new File("house.dat");
            FileInputStream fStream = new FileInputStream(f);
            ObjectInputStream oStream = new ObjectInputStream(fStream);
            //read the object from file
            house=(ArrayList <House>)oStream.readObject();
            //close the stream
            oStream.close();
            
        }
        catch(IOException|ClassNotFoundException ex){
            System.out.println(ex);
            
        }
    }
     public void writeToFilePerson(){
        try{
            File r = new File("person.dat");//declare and create File object
            FileOutputStream fStream = new FileOutputStream(r);
            ObjectOutputStream oStream = new ObjectOutputStream(fStream);
            //write the object
            oStream.writeObject(person);
            //close the output stream
            oStream.close();
            
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    public void readFromFilePerson(){
        try{
            //declare and create objects for input
            File r = new File("person.dat");
            FileInputStream fStream = new FileInputStream(r);
            ObjectInputStream oStream = new ObjectInputStream(fStream);
            //read the object from file
            person=(ArrayList <Person>)oStream.readObject();
            //close the stream
            oStream.close();
            
        }
        catch(IOException|ClassNotFoundException ex){
            System.out.println(ex);
            
        }
    }
    public void writeToFileArea(){
        try{
            File f = new File("area.dat");//declare and create File object
            FileOutputStream fStream = new FileOutputStream(f);
            ObjectOutputStream oStream = new ObjectOutputStream(fStream);
            //write the object
            oStream.writeObject(areaList);
            //close the output stream
            oStream.close();
            
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    public void readFromFileArea(){
        try{
            //delcare and create objects for input
            File f = new File("area.dat");
            FileInputStream fStream = new FileInputStream(f);
            ObjectInputStream oStream = new ObjectInputStream(fStream);
            //read the object from file
            areaList=(ArrayList <Area>)oStream.readObject();
            //close the stream
            oStream.close();
            
        }
        catch(IOException|ClassNotFoundException ex){
            System.out.println(ex);
            
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HouseAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HouseAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HouseAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HouseAppGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HouseAppGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addLbl;
    private javax.swing.JButton addPeopleBtn;
    private javax.swing.JButton areaAddBtn;
    private javax.swing.JLabel areaLbl;
    private javax.swing.JButton areaMbtn;
    private javax.swing.JLabel areaPriceLbl;
    private javax.swing.JTextField areaPriceTf;
    private javax.swing.JTextField areaTf;
    private javax.swing.JButton bigBtn;
    private javax.swing.JButton buyAHouseBtn;
    private javax.swing.JButton calcTotalBtn;
    private javax.swing.JButton calculateGBtn;
    private javax.swing.JButton chooseAreaBtn;
    private javax.swing.JButton chooseHouseBtn;
    private javax.swing.JTextField chosenHousePriceTf;
    private javax.swing.JLabel chosenLbl;
    private javax.swing.JButton clearBtn;
    private javax.swing.JButton deleteHouseBtn;
    private javax.swing.JButton deletePersonBtn;
    private javax.swing.JCheckBox disabledCBox;
    private javax.swing.JButton displayAreaBtn;
    private javax.swing.JButton displayHouseBtn;
    private javax.swing.JButton displayInfobtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JLabel floorNumLbl;
    private javax.swing.JTextField floorNumTf;
    private javax.swing.JLabel garageLimitLbl;
    private javax.swing.JTextField garageLimitTf;
    private javax.swing.JLabel gardenSizeLbl;
    private javax.swing.JTextField gardenSizeTf;
    private javax.swing.JLabel grantAmountLbl;
    private javax.swing.JTextField grantAmountTf;
    private javax.swing.JButton grantBtn;
    private javax.swing.JLabel hTypeLbl;
    private javax.swing.JTextField hTypeTf;
    private javax.swing.JButton houseAddBtn;
    private javax.swing.JLabel incomeLbl;
    private javax.swing.JTextField incomeTf;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel mYearsLbl;
    private javax.swing.JTextField mYearsTf;
    private javax.swing.JButton marriedBtn;
    private javax.swing.JButton mediumBtn;
    private javax.swing.JButton northBtn;
    private javax.swing.JLabel northCodeLbl;
    private javax.swing.JTextField northCodeTf;
    private javax.swing.JLabel pAgeLbl;
    private javax.swing.JTextField pAgeTf;
    private javax.swing.JLabel pNameLbl;
    private javax.swing.JTextField pNameTf;
    private javax.swing.JCheckBox parentCBox;
    private javax.swing.JButton payBtn;
    private javax.swing.JLabel poolSizeLbl;
    private javax.swing.JTextField poolSizeTf;
    private javax.swing.JLabel priceAreaLbl;
    private javax.swing.JTextField priceAreaTf;
    private javax.swing.JLabel priceLbl;
    private javax.swing.JTextField priceTf;
    private javax.swing.JLabel roomNumLbl;
    private javax.swing.JTextField roomNumTf;
    private javax.swing.JButton searchAreaBtn;
    private javax.swing.JButton searchHouseBtn;
    private javax.swing.JButton searchPBtn;
    private javax.swing.JButton singleBtn;
    private javax.swing.JButton southBtn;
    private javax.swing.JLabel southCodeLbl;
    private javax.swing.JTextField southCodeTf;
    private javax.swing.JCheckBox studentCBox;
    private javax.swing.JButton submitBtn;
    private javax.swing.JButton submitHouseBtn;
    private javax.swing.JLabel timeToCityLbl;
    private javax.swing.JTextField timeToCityTf;
    private javax.swing.JLabel titleLbl;
    private javax.swing.JLabel totalPriceLbl;
    private javax.swing.JTextField totalPriceTf;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JCheckBox unemployedCBox;
    // End of variables declaration//GEN-END:variables
}
