/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public class BigHouse extends House implements Serializable{
    private String gardenSize, poolSize;
    private int garageLimit;
    
    public BigHouse(String type, int roomNum, int floorNum, double price, String gardenSize, String poolSize, int garageLimit)
    {
        super(type, roomNum, floorNum, price);
        this.garageLimit = garageLimit;
        this.gardenSize = gardenSize;
        this.poolSize = poolSize;
    }
    public BigHouse()
    {
        super();
        int garageLimit=0;
        String gardenSize="";
        String poolSize="";
        
    }

    public String getGardenSize() {
        return gardenSize;
    }

    public void setGardenSize(String gardenSize) {
        this.gardenSize = gardenSize;
    }

    public String getPoolSize() {
        return poolSize;
    }

    public void setPoolSize(String poolSize) {
        this.poolSize = poolSize;
    }

    public int getGarageLimit() {
        return garageLimit;
    }

    public void setGarageLimit(int garageLimit) {
        this.garageLimit = garageLimit;
    }

    
    @Override
    public String printDetails(){
        return super.printDetails()+"\nSize of garden: "+ gardenSize+"\nSize of swimming pool: "+poolSize+"\nNo.of vehicles the garage will fit: "+ garageLimit;
    }
}
