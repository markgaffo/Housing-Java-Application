/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author Anthony
 */
public class Person implements Serializable {
    String name;
    int age;
   
    
    public Person(){
        name = "";
        age=0;
       
    }
    public Person(String name, int age){
        this.name=name;
        this.age=age;
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

   
    
    public String printPerDetails(){
        return "Name: "+name+"\n Age: "+age;
    }
    
}
