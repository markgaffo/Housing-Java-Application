/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author Anthony
 */
public class Married extends Person implements Serializable {
    private int yearsMarried;
    
    
   public Married(String name, int age, int yearsMarried){
       super(name, age);
       this.yearsMarried=yearsMarried;
       
   } 
   public Married(){
       super();
       int yearsMarried=0;
       
   }

    public int getYearsMarried() {
        return yearsMarried;
    }

    public void setYearsMarried(int yearsMarried) {
        this.yearsMarried = yearsMarried;
    }
    @Override
   public String printPerDetails(){
        return super.printPerDetails()+"\nNo. of years married: "+yearsMarried;
    }
}
