/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public class NorthDub extends Area implements Serializable {
   private int northPostCode;
   
   public NorthDub(String area, double areaPricing, int timeToCity, int northPostCode){
       super(area, areaPricing, timeToCity);
       this.northPostCode=northPostCode;
     
   }
   public NorthDub(){
       super();
       int northPostCode=0;
   }

    public int getNorthPostCode() {
        return northPostCode;
    }

    public void setNorthPostCode(int northPostCode) {
        this.northPostCode = northPostCode;
    }
   @Override
   public String printAreaDetails(){
       return super.printAreaDetails()+"\n North side postcode number: "+northPostCode;
   }
}
