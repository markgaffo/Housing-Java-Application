/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author Anthony
 */
public class Single extends Person implements Serializable {
    
    private double income;
    public Single(String name, int age, double income){
       super(name, age);
       this.income=income;
       
   } 
   public Single(){
       super();
       int income = 0;
       
   }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    @Override
   public String printPerDetails(){
        return super.printPerDetails()+"\n Total income: "+income;
    }
}
