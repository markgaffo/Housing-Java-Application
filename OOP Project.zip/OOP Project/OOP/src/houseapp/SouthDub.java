/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public class SouthDub extends Area implements Serializable{
   private int southPostCode;
     
   
   public SouthDub(String area, double areaPricing, int timeToCity, int southPostCode){
       super(area, areaPricing, timeToCity);
       this.southPostCode=southPostCode;
     
   }
   public SouthDub(){
       super();
       int southPostCode=0;
   }

    public int getSouthPostCode() {
        return southPostCode;
    }

    public void setSouthPostCode(int southPostCode) {
        this.southPostCode = southPostCode;
    }
   @Override
   public String printAreaDetails(){
       return super.printAreaDetails()+"\n South side postcode number: "+southPostCode;
   }
}
