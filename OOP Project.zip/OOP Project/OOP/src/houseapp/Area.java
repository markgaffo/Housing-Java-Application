/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public abstract class Area implements Serializable {
    String area;
    double areaPricing;
    int timeToCity;
    
    
   public Area(){
       area = "";
       areaPricing = 0;
       timeToCity = 0;
   } 
   public Area(String area, double areaPricing, int timeToCity){
       this.area=area;
       this.areaPricing=areaPricing;
       this.timeToCity=timeToCity;
       
   } 

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public double getAreaPricing() {
        return areaPricing;
    }

    public void setAreaPricing(double areaPricing) {
        this.areaPricing = areaPricing;
    }

    public int getTimeToCity() {
        return timeToCity;
    }

    public void setTimeToCity(int timeToCity) {
        this.timeToCity = timeToCity;
    }
    public String printAreaDetails(){
        return "Area: "+area+"\n Addition price based on area: "+areaPricing+"\n Time(minutes) needed to get to City Centre: "+timeToCity;
    }
}
