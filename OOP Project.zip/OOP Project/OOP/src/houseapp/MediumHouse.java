/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package houseapp;

import java.io.Serializable;

/**
 *
 * @author x17145953
 */
public class MediumHouse extends House implements Serializable{
    
    private String gardenSize;
    private int garageLimit;
    
    public MediumHouse(String type, int roomNum,int floorNum, double price, String gardenSize, int garageLimit){
    super(type, roomNum, floorNum, price);
    this.gardenSize=gardenSize;
    this.garageLimit=garageLimit;
    }
    
    public MediumHouse()
    {
        super();
        String gardenSize="";
        int garageLimit=0;
        
    }

    public String getGardenSize() {
        return gardenSize;
    }

    public void setGardenSize(String gardenSize) {
        this.gardenSize = gardenSize;
    }

    public int getGarageLimit() {
        return garageLimit;
    }

    public void setGarageLimit(int garageLimit) {
        this.garageLimit = garageLimit;
    }

    
    
    @Override
    public String printDetails(){
        return super.printDetails()+"\nSize of garden: "+ gardenSize+"\nNo.of vehicles the garage will fit: "+ garageLimit;
    }
}
